# HSQ128R CONTROL MAX v2.0

Android WebView app with expanded local HSQ128R CONTROL MAX features.

GitHub: Actions → Build HSQ128R CONTROL MAX APK → Run workflow → Artifacts.
